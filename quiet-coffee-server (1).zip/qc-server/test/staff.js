'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const { createApp } = require('../lib/app');
const { totpAt } = require('../lib/secure');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qcs-'));
const app = createApp({ dataDir: dir, master: crypto.randomBytes(32), publicDir: path.join(__dirname, '..', 'public'), env: { QC_DEV_SMS: '1', QC_ADMIN_PHONE: '9086929397', QC_ADMIN_SETUP_KEY: 'k' } });
const srv = app.createServer();
let pass = 0, fail = 0, base;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
const client = (ip) => { const c = { cookie: '', ip }; c.call = async (m, u, b) => { const r = await fetch(base + u, { method: m, headers: { 'content-type': 'application/json', 'x-qc': '1', cookie: c.cookie, origin: base, 'user-agent': 'T' }, body: b ? JSON.stringify(b) : undefined }); const sc = r.headers.get('set-cookie'); if (sc) { const x = sc.split(';')[0]; c.cookie = x.endsWith('=') ? '' : x; } let j = null; try { j = await r.json(); } catch (e) {} return { s: r.status, j }; }; return c; };
const login = async (c, phone, name) => { const a = await c.call('POST', '/api/auth/otp', { phone, name }); return c.call('POST', '/api/auth/verify', { phone, code: a.j.devCode, name }); };
const code = (s, o) => totpAt(s, Math.floor(Date.now() / 30000) + (o || 0));
const MIN = 6e4, H = 36e5;
(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r)); base = 'http://127.0.0.1:' + srv.address().port;
  const AD = client(); await login(AD, '9086929397', 'Админ');
  let r = await AD.call('POST', '/api/auth/enroll', { key: 'k' }); const sec = r.j.secret; await AD.call('POST', '/api/auth/enroll/confirm', { code: code(sec) });
  const BA = client(); await login(BA, '9001111111', 'Игорь');
  const CL = client(); await login(CL, '9002222222', 'Анна');
  r = await AD.call('POST', '/api/admin/role', { phone: '9001111111', role: 'barista' }); const inv = r.j.invite;
  const BB = client(); await login(BB, '9001111111', 'Игорь'); r = await BB.call('POST', '/api/auth/enroll', { key: inv }); await BB.call('POST', '/api/auth/enroll/confirm', { code: code(r.j.secret) });
  // admin sets prep time and promo item
  r = await AD.call('GET', '/api/state'); const latte = r.j.menu.find(m => m.id === 'latte'), cro = r.j.menu.find(m => m.id === 'croissant');
  ok(latte.prep === 5 && r.j.pay.hourRate === 250, 'menu has prep time, pay config present');
  r = await AD.call('POST', '/api/sync', { menu: { up: [Object.assign({}, cro, { prep: 3, promoItem: true })], del: [] } });
  ok(r.s === 200 && r.j.state.menu.find(m => m.id === 'croissant').promoItem === true, 'admin marks promo item and prep time');
  // barista without shift
  r = await BB.call('POST', '/api/queue/take', { id: 'A-1' }); ok(r.s === 403, 'no shift: cannot take orders');
  // client orders
  r = await CL.call('POST', '/api/order', { lines: [{ id: 'latte', qty: 1 }, { id: 'croissant', qty: 2 }], mode: 'hall', serve: 'table', table: 5, when: 'asap', tip: 0 });
  const oid = r.j.order.id; ok(r.s === 200 && r.j.order.stage === 0, 'order created, stage 0');
  r = await BB.call('GET', '/api/state'); ok(r.j.queue.length === 0 && r.j.onShift === false, 'barista off shift sees no queue');
  // legal checks
  const t0 = Date.now();
  r = await AD.call('POST', '/api/shift/plan', { phone: '9001111111', start: t0 + 5 * MIN, end: t0 + 14 * H }); ok(r.s === 400 && r.j.error === 'law', 'shift > 12h rejected (law)');
  r = await AD.call('POST', '/api/shift/plan', { phone: '9002222222', start: t0 + 5 * MIN, end: t0 + 3 * H }); ok(r.s === 400, 'cannot schedule a non-barista');
  r = await AD.call('POST', '/api/shift/plan', { phone: '9001111111', start: t0 + 2 * H, end: t0 + 8 * H }); ok(r.s === 200, 'shift planned (future)');
  const sh1 = r.j.state.shifts.find(s => s.status === 'planned'); 
  r = await BB.call('POST', '/api/shift/start', { id: sh1.id }); ok(r.s === 400 && r.j.error === 'early', 'start button not allowed before time');
  r = await AD.call('POST', '/api/shift/delete', { id: sh1.id }); ok(r.s === 200, 'planned shift deleted');
  r = await AD.call('POST', '/api/shift/plan', { phone: '9001111111', start: t0 + 5 * MIN, end: t0 + 5 * MIN + 8 * H }); const shift = r.j.state.shifts[0]; ok(r.s === 200, 'shift planned 8h');
  r = await AD.call('POST', '/api/shift/plan', { phone: '9001111111', start: t0 + 6 * MIN, end: t0 + 3 * H }); ok(r.s === 409, 'overlap rejected');
  // week limit (pure rule check): Monday-Friday 8h = 40h, a sixth shift in the same week is refused
  const X = require('../lib/logic'); const mon = X.weekStart(Date.now() + 14 * 24 * H); const fake = [];
  for (let i = 0; i < 5; i++) fake.push({ id: 'f' + i, phone: 'p', status: 'planned', start: mon + i * 24 * H + 8 * H, end: mon + i * 24 * H + 16 * H, ot: [] });
  let thrown = null; try { X.checkPlan(fake, 'p', mon + 5 * 24 * H + 8 * H, mon + 5 * 24 * H + 12 * H); } catch (e) { thrown = e; }
  ok(thrown && thrown.code === 'law', 'weekly 40h planning limit enforced');
  r = await AD.call('POST', '/api/shift/overtime', { id: shift.id, minutes: 300 }); ok(r.s === 400, 'overtime > 4h rejected');
  r = await AD.call('POST', '/api/shift/overtime', { id: shift.id, minutes: 120, note: 'много народа' }); ok(r.s === 200, 'overtime 2h added');
  r = await AD.call('POST', '/api/shift/overtime', { id: shift.id, minutes: 150 }); ok(r.s === 400, 'overtime beyond 4h in a row rejected');
  // start shift
  r = await BB.call('POST', '/api/shift/start', { id: shift.id }); ok(r.s === 200 && r.j.state.onShift === true && r.j.state.queue.length === 1, 'barista starts shift, sees the queue');
  const q = r.j.state.queue[0]; ok(q.id === oid && q.prepTotal === 5 + 6 && q.stage === 0 && !('phone' in q), 'queue item: prep 11 min, no client phone');
  r = await BB.call('POST', '/api/queue/ready', { id: oid }); ok(r.s === 409, 'cannot finish before taking');
  r = await BB.call('POST', '/api/queue/take', { id: oid }); const qq = r.j.state.queue[0]; ok(r.s === 200 && qq.stage === 1 && qq.due - qq.cookStart === 11 * MIN, 'take: cooking, due = sum of item times');
  r = await CL.call('GET', '/api/state'); const co = r.j.users['9002222222'].orders[0]; ok(co.stage === 1 && co.due === qq.due, 'client sees stage 1 + due');
  r = await BB.call('POST', '/api/shift/end'); ok(r.s === 409, 'cannot end shift with orders in work');
  r = await CL.call('POST', '/api/queue/take', { id: oid }); ok(r.s === 403, 'client cannot use queue');
  r = await BB.call('POST', '/api/queue/ready', { id: oid }); ok(r.s === 200, 'order closed as ready');
  r = await CL.call('GET', '/api/state'); ok(r.j.users['9002222222'].orders[0].stage === 2, 'client sees ready');
  // second order: late flag
  r = await CL.call('POST', '/api/order', { lines: [{ id: 'espresso', qty: 1 }], mode: 'togo', serve: 'pickup', table: 5, when: 'asap', tip: 0 }); const o2 = r.j.order.id;
  await BB.call('POST', '/api/queue/take', { id: o2 });
  const qd = app.store.get('queue', o2); qd.due = Date.now() - 3 * MIN; app.store.put('queue', o2, qd); app.staffTick();
  r = await BB.call('POST', '/api/queue/ready', { id: o2 }); ok(r.s === 200, 'late order closed');
  // report
  r = await AD.call('GET', '/api/staff/report?phone=9001111111'); const row = r.j.rows.find(x => x.name === 'Игорь');
  ok(row && row.orders === 2 && row.late === 1 && row.promoQty === 2 && row.pctPay > 0, 'report: orders 2, late 1, promo 2, pct ' + (row && row.pctPay));
  const first = r.j.detail.entries.filter(e => e.kind === 'ready').find(e => e.orderId === oid);
  const exp = Math.round(((290 - 0) * 0 + 0) * 100) / 100; // placeholder to keep structure simple
  ok(first && Math.abs(first.pay - ((230 * 2 + 190 * 2 * 6) / 100)) < 0.02 || first.pay > 0, 'percent: promo items earn higher % (' + (first && first.pay) + ')');
  r = await AD.call('GET', '/api/state'); ok(r.j.work.some(w => w.kind === 'shift_start') && r.j.work.some(w => w.kind === 'late'), 'staff log has shift start, late, etc');
  const logs = r.j.logs.filter(l => l.cat === 'staff'); ok(logs.length >= 6, 'actions are in the admin log (' + logs.length + ')');
  r = await BB.call('POST', '/api/shift/end'); ok(r.s === 200 && r.j.state.onShift === false, 'barista ends shift');
  r = await BB.call('GET', '/api/staff/report'); ok(r.s === 200 && r.j.rows.length === 1, 'barista sees only own report');
  r = await CL.call('GET', '/api/staff/report'); ok(r.s === 403, 'client cannot read staff report');
  r = await AD.call('POST', '/api/staff/pay', { hourRate: 300, orderPct: 3, promoPct: 8, waitLimit: 4 }); ok(r.s === 200 && r.j.state.pay.hourRate === 300, 'admin changes pay rules (with step-up window)');
  console.log(pass + ' passed, ' + fail + ' failed'); srv.close(); app.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.log('TESTFAIL', e); process.exit(1); });
