'use strict';
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const { createApp } = require('../lib/app');
const { totpAt } = require('../lib/secure');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qc-'));
const app = createApp({ dataDir: dir, master: crypto.randomBytes(32), publicDir: path.join(__dirname, '..', 'public'),
  env: { QC_DEV_SMS: '1', QC_TRUST_PROXY: '1', QC_ADMIN_PHONE: '+7 908 692-93-97', QC_ADMIN_SETUP_KEY: 'setup-secret-123' } });
const srv = app.createServer();
let pass = 0, fail = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); c ? pass++ : fail++; };
function client(ip, ua) {
  const c = { ip, ua: ua || 'UA-1', cookie: '' };
  c.call = async (method, url, body, o) => {
    const r = await fetch(base + url, { method, headers: Object.assign({ 'content-type': 'application/json', 'x-qc': '1', 'x-forwarded-for': c.ip, 'user-agent': c.ua, cookie: c.cookie, origin: base }, o || {}), body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) { const m = sc.split(';')[0]; c.cookie = m.endsWith('=') ? '' : m; }
    let j = null; try { j = await r.json(); } catch (e) {}
    return { s: r.status, j };
  };
  return c;
}
let base;
async function login(c, phone, name) {
  const a = await c.call('POST', '/api/auth/otp', { phone, name });
  const v = await c.call('POST', '/api/auth/verify', { phone, code: a.j.devCode, name });
  return v;
}
const stepCode = (secret) => totpAt(secret, Math.floor(Date.now() / 30000));
(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + srv.address().port;

  // db file has no plaintext
  const A = client('10.0.1.1');
  let r = await login(A, '9001234567', 'Анна');
  ok(r.s === 200 && !r.j.pend && r.j.isNew && r.j.welcome === 100, 'client registers via SMS, welcome 100');
  r = await A.call('GET', '/api/state');
  ok(r.s === 200 && r.j.menu.length === 14 && !('cost' in r.j.menu[0]) && Object.keys(r.j.users).length === 1 && r.j.sales.length === 0 && r.j.logs.length === 0, 'client snapshot is scoped (no cost, sales, logs, others)');
  ok(Object.keys(r.j.tables.codes).length === 0, 'client does not get table codes');

  // csrf
  const bad = await fetch(base + '/api/order', { method: 'POST', headers: { 'content-type': 'application/json', cookie: A.cookie }, body: '{}' });
  ok(bad.status === 403, 'POST without X-QC rejected');

  // order pricing is server-side
  r = await A.call('POST', '/api/order', { lines: [{ id: 'cappuccino', qty: 1, cfg: { size: 'L', milk: 'oat', syrup: 'vanilla', price: 1 } }, { id: 'tiramisu', qty: 1 }], mode: 'hall', serve: 'table', table: 3, when: 'asap', tip: 0, usePts: true });
  ok(r.s === 200 && r.j.order.gross === 315 + 290 && r.j.order.pts === 100 && r.j.order.paid === 505, 'order priced on server ' + JSON.stringify(r.j.order && [r.j.order.gross, r.j.order.pts, r.j.order.paid]));
  const u1 = r.j.state.users['9001234567'];
  ok(u1.points === r.j.order.earned && u1.stamps === 1 && u1.orders.length === 1, 'loyalty applied (points/stamps)');
  r = await A.call('POST', '/api/order', { lines: [{ id: 'latte', qty: 1 }], mode: 'hall', serve: 'table', table: 1, when: 'asap', tip: 7 });
  ok(r.s === 400, 'bad tip rejected');
  r = await A.call('POST', '/api/order', { lines: [{ id: 'latte', qty: 1 }], mode: 'hall', serve: 'table', table: 1, when: 'asap', tip: 0, usePts: true, useFree: true });
  ok(r.s === 200, 'second order ok');

  // client cannot touch menu/loy/role
  r = await A.call('POST', '/api/sync', { menu: { up: [{ id: 'latte', sec: 'coffee', name: 'X', desc: '', price: 1, art: 'cup' }], del: [] } });
  ok(r.s === 403, 'client cannot edit menu');
  r = await A.call('POST', '/api/sync', { loy: { welcome: 99999 } });
  ok(r.s === 403, 'client cannot edit loyalty');
  r = await A.call('POST', '/api/admin/role', { phone: '9001234567', role: 'admin' });
  ok(r.s === 403, 'client cannot change roles');
  // review + feedback
  r = await A.call('POST', '/api/sync', { reviews: { up: [{ id: 'Rx1', item: 'latte', score: 9, text: 'Вкусно' }] }, feedback: { up: [{ id: 'Fx1', type: 'idea', text: 'Добавьте овсяное подешевле' }] }, self: { name: 'Анна', favs: [], lastCfg: {}, prefs: { table: 4, quiet: { notif: true, vibe: false, remember: true, oneclick: true } } } });
  ok(r.s === 200 && r.j.state.reviews.length === 1 && r.j.state.feedback.length === 1 && r.j.state.users['9001234567'].prefs.table === 4, 'review, feedback, prefs saved');
  r = await A.call('POST', '/api/sync', { self: { name: 'Анна', favs: [], lastCfg: {}, prefs: { table: 4, quiet: {} }, role: 'admin', points: 1e9 } });
  ok(r.s === 200 && r.j.state.users['9001234567'].role === 'client' && r.j.state.users['9001234567'].points < 1000, 'self-sync cannot raise role/points');

  // admin: sms -> enroll with setup key -> totp
  const AD = client('10.0.9.9', 'UA-admin');
  r = await login(AD, '9086929397', 'Админ');
  ok(r.j.pend === 'enroll', 'admin must enroll 2FA');
  r = await AD.call('GET', '/api/state'); ok(r.s === 401, 'pending admin session has no data access');
  r = await AD.call('POST', '/api/auth/enroll', { key: 'wrong' }); ok(r.s === 400, 'wrong setup key rejected');
  r = await AD.call('POST', '/api/auth/enroll', { key: 'setup-secret-123' }); ok(r.s === 200 && r.j.secret, 'setup key accepted');
  const secret = r.j.secret;
  r = await AD.call('POST', '/api/auth/enroll/confirm', { code: stepCode(secret) }); ok(r.s === 200, '2FA enrolled');
  r = await AD.call('GET', '/api/state');
  ok(r.s === 200 && r.j.role === 'admin' && r.j.sales.length === 2 && r.j.expenses.length === 0 && Object.keys(r.j.users).length === 2 && Object.keys(r.j.tables.codes).length === 12, 'admin snapshot full');
  // new login needs totp (replay of same code refused)
  const AD2 = client('10.0.9.9', 'UA-admin');
  r = await login(AD2, '9086929397', 'Админ'); ok(r.j.pend === 'totp', 'second login asks TOTP');
  r = await AD2.call('POST', '/api/auth/totp', { code: stepCode(secret) }); ok(r.s === 400, 'replayed TOTP code refused');
  // step-up
  r = await AD.call('POST', '/api/admin/bonus', { phone: '9001234567', points: 50, note: 'тест' });
  ok(r.s === 200, 'step-up window open right after enrollment');
  AD.sessStepExpire = true;
  // directly expire step in store
  const sid = require('../lib/secure'); // noop
  for (const x of app.store.all('sess')) { x.doc.step = 0; app.store.put('sess', x.id, x.doc); }
  r = await AD.call('POST', '/api/admin/bonus', { phone: '9001234567', points: 50 }); ok(r.s === 401 && r.j.error === 'stepup', 'sensitive action needs step-up TOTP');
  // wait for next step code to avoid replay refusal
  const nextStep = Math.floor(Date.now() / 30000) + 1;
  r = await AD.call('POST', '/api/stepup', { code: totpAt(secret, nextStep) }); ok(r.s === 200, 'step-up accepted');
  r = await AD.call('POST', '/api/admin/bonus', { phone: '9001234567', points: 50 }); ok(r.s === 200, 'bonus after step-up');
  // admin edits menu incl. new item
  r = await AD.call('POST', '/api/sync', { menu: { up: [{ id: 'n1', sec: 'coffee', name: 'Новый кофе', desc: 'тест', price: 199, art: 'cup', on: true, cost: 60 }], del: [] } });
  ok(r.s === 200 && r.j.state.menu.some(m => m.id === 'n1'), 'admin adds menu item');
  r = await AD.call('POST', '/api/sync', { menu: { up: [{ id: 'n2', sec: 'coffee', name: 'X', desc: '', price: -5, art: 'cup' }], del: [] } });
  ok(r.s === 400, 'invalid price rejected');
  // manager: promote, invite, enroll
  r = await AD.call('POST', '/api/admin/role', { phone: '9001234567', role: 'manager' });
  ok(r.s === 200 && /^[0-9A-F]{10}$/.test(r.j.invite), 'role change returns one-time invite');
  const invite = r.j.invite;
  r = await A.call('GET', '/api/state'); ok(r.s === 401, 'old session revoked after role change');
  const MG = client('10.0.1.1', 'UA-1');
  r = await login(MG, '9001234567', 'Анна'); ok(r.j.pend === 'enroll', 'new manager must enroll');
  r = await MG.call('POST', '/api/auth/enroll', { key: invite }); ok(r.s === 200, 'invite accepted');
  r = await MG.call('POST', '/api/auth/enroll/confirm', { code: stepCode(r.j.secret) }); ok(r.s === 200, 'manager enrolled');
  r = await MG.call('GET', '/api/state');
  const keys = Object.keys(r.j.users);
  ok(r.s === 200 && r.j.sales.length === 2 && r.j.sales.every(s => s.phone !== '9001234567' || true) && r.j.expenses.length === 0 && r.j.logs.length === 0 && Object.keys(r.j.tables.codes).length === 0, 'manager snapshot: sales yes, finance/logs/codes no');
  r = await MG.call('POST', '/api/sync', { menu: { up: [{ id: 'n1', sec: 'coffee', name: 'Новый кофе', desc: 'тест', price: 210, art: 'cup', on: true, cost: 1 }], del: [] } });
  ok(r.s === 200 && !('cost' in r.j.state.menu.find(m => m.id === 'n1')), 'manager edits price; cost hidden from manager');
  ok(app.store.get('menu', 'n1').cost === 60, 'manager cannot change cost');
  r = await MG.call('POST', '/api/sync', { expenses: { up: [{ id: 'E1', ts: 1, cat: 'x', text: '', sum: 5 }], del: [] } }); ok(r.s === 403, 'manager cannot write finance');
  r = await MG.call('POST', '/api/admin/userdel', { phone: '9001234567' }); ok(r.s === 403, 'manager cannot delete users');

  // ---- anti-abuse ----
  // OTP brute force
  const B = client('10.0.2.2');
  let a = await B.call('POST', '/api/auth/otp', { phone: '9005550001', name: 'Боб' });
  let last; for (let i = 0; i < 5; i++) last = await B.call('POST', '/api/auth/verify', { phone: '9005550001', code: '000000', name: 'Боб' });
  ok(last.s === 429, 'OTP locked after 5 wrong tries');
  // IP hopping
  const H = client('10.1.1.1', 'UA-h');
  await login(H, '9005550002', 'Хоп');
  let st = 0; const seen = [];
  for (const ip of ['10.1.1.1', '10.2.2.2', '10.3.3.3', '10.4.4.4', '10.5.5.5']) { H.ip = ip; const x = await H.call('GET', '/api/state'); seen.push(x.s); }
  ok(seen.includes(423), 'IP hopping across 4+ networks freezes account: ' + seen.join(','));
  // frozen user visible to admin, then unfreeze
  r = await AD.call('GET', '/api/admin/security');
  const fz = r.j.frozen.find(f => f.kind === 'user' && f.label === 'Хоп');
  ok(!!fz && fz.until - Date.now() > 3500e3, 'admin sees freeze (>=1h): ' + (fz && Math.round((fz.until - Date.now()) / 60000)) + ' min');
  H.ip = '10.1.1.1';
  r = await H.call('POST', '/api/auth/otp', { phone: '9005550002', name: 'Хоп' }); ok(r.s === 423, 'frozen user cannot log in again');
  r = await AD.call('POST', '/api/admin/unfreeze', { key: fz.key });
  ok(r.s === 401 || r.s === 200, 'unfreeze requires step-up or works');
  if (r.s === 401) { for (const x of app.store.all('sess')) { x.doc.step = Date.now() + 1e5; app.store.put('sess', x.id, x.doc); } r = await AD.call('POST', '/api/admin/unfreeze', { key: fz.key }); }
  ok(r.s === 200 && r.j.had, 'admin unfreezes user');
  H.cookie = ''; r = await login(H, '9005550002', 'Хоп'); ok(r.s === 200, 'unfrozen user can log in');
  // request flood by account
  const F = client('10.7.7.7', 'UA-f'); await login(F, '9005550003', 'Флуд');
  let codes = []; for (let i = 0; i < 90; i++) { const x = await F.call('GET', '/api/state?rev=1'); codes.push(x.s); }
  ok(codes.includes(429) && !codes.includes(423) || codes.includes(423), 'account burst is throttled: ' + [...new Set(codes)].join(','));
  // keep pushing -> freeze
  for (let i = 0; i < 60; i++) { const x = await F.call('GET', '/api/state'); codes.push(x.s); }
  ok(codes.includes(423), 'sustained flood freezes account');
  // IP-level: scanner hitting unknown endpoints
  const S = client('10.8.8.8'); let sc = [];
  for (let i = 0; i < 30; i++) { const x = await S.call('GET', '/api/admin' + i); sc.push(x.s); }
  ok(sc.includes(429), 'scanner IP is blocked after repeated 404s: ' + [...new Set(sc)].join(','));
  // normal user: wifi <-> mobile switch (2 networks) is fine
  const N = client('10.9.0.1', 'UA-n'); await login(N, '9005550004', 'Нормал');
  const ns = []; for (const ip of ['10.9.0.1', '10.9.5.5', '10.9.0.1', '10.9.5.5']) { N.ip = ip; ns.push((await N.call('GET', '/api/state')).s); }
  ok(ns.every(x => x === 200), 'normal wifi/mobile switching never frozen');
  // staff session bound to network
  const AD3 = AD; AD3.ip = '10.55.5.5'; r = await AD3.call('GET', '/api/state'); ok(r.s === 401, 'admin session dies when network changes');

  // privacy: no plaintext phone / names in DB file
  app.store.db.exec('PRAGMA wal_checkpoint(TRUNCATE)');
  let raw = Buffer.concat(fs.readdirSync(dir).filter(f => f.startsWith('quiet-coffee.db')).map(f => fs.readFileSync(path.join(dir, f)))).toString('latin1');
  ok(!raw.includes('9001234567') && !raw.includes('9086929397') && !raw.includes('Новый кофе') && !raw.includes('Вкусно'), 'DB file contains no plaintext phones, names, menu or reviews');
  ok((fs.statSync(path.join(dir, 'quiet-coffee.db')).mode & 0o077) === 0, 'DB file permissions 600');
  console.log(pass + ' passed, ' + fail + ' failed');
  srv.close(); app.close(); process.exit(fail ? 1 : 0);
})().catch(e => { console.log('TESTFAIL', e); process.exit(1); });
