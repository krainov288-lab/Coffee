const { chromium } = require('playwright');
const { spawn } = require('node:child_process');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
const { totpAt } = require('../lib/secure');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qcui-'));
const PORT = 18080;
const srv = spawn('node', ['--no-warnings', path.join(__dirname, '..', 'server.js')], { env: Object.assign({}, process.env, { QC_PORT: PORT, QC_DATA: dir + '/data', QC_KEY_FILE: dir + '/secrets/master.key', QC_DEV_SMS: '1', QC_ADMIN_PHONE: '+79086929397', QC_ADMIN_SETUP_KEY: 'setup-key-777' }), stdio: ['ignore', 'pipe', 'pipe'] });
let slog = ''; srv.stdout.on('data', d => slog += d); srv.stderr.on('data', d => slog += d);
const ok = (c, m) => console.log((c ? 'PASS ' : 'FAIL ') + m);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
(async () => {
  await sleep(1200);
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: 400, height: 860 } });
  const pg = await ctx.newPage();
  const errs = [];
  pg.on('pageerror', e => errs.push('PAGEERR ' + e.message));
  pg.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE ' + m.text()); });
  await pg.route('**/jsQR.js', r => r.fulfill({ contentType: 'text/javascript', body: 'window.jsQR=function(){return null}' }));
  await pg.route('**/qrcode.js', r => r.fulfill({ contentType: 'text/javascript', body: 'window.qrcode=function(){return {addData(){},make(){},getModuleCount(){return 21},isDark(r,c){return (r*c+r)%3==0}}}' }));
  await pg.route(/fonts\.(googleapis|gstatic)\.com/, r => r.abort());
  const U = 'http://127.0.0.1:' + PORT + '/';
  await pg.goto(U);
  await pg.waitForSelector('#regform');
  ok(await pg.locator('[data-a=demo]').count() === 0, 'no demo login any more');
  // client registration
  await pg.fill('#nm', 'Анна'); await pg.fill('#ph', '+7 900 123-45-67'); await pg.click('[data-a=sendcode]');
  await pg.waitForSelector('#cd');
  await pg.waitForFunction(() => /Ваш код: \d{6}/.test(document.getElementById('toast').textContent));
  const code = (await pg.textContent('#toast')).match(/(\d{6})/)[1];
  await pg.fill('#cd', '000000');
  await pg.waitForFunction(() => /не подходит/.test(document.getElementById('regerr').textContent));
  ok(true, 'wrong SMS code shows error');
  await pg.fill('#cd', code);
  await pg.waitForSelector('.hd .logo'); await sleep(300);
  ok(/приветственных баллов/.test(await pg.textContent('#toast')), 'registered, welcome bonus');
  // order
  await pg.click('nav [data-s=coffee]');
  await pg.click('.pc[data-id=latte]');
  await pg.click('[data-a=addDrink]');
  await pg.click('nav [data-s=cart]');
  await pg.click('[data-a=go][data-s=pay]').catch(() => {});
  const payBtn = pg.locator('[data-a=doPay]');
  if (!(await payBtn.count())) { await pg.click('[data-s=pay]'); }
  await pg.click('[data-a=doPay]');
  await pg.waitForFunction(() => /Заказ A-\d+ принят/.test(document.getElementById('toast').textContent));
  ok(true, 'order paid on server: ' + (await pg.textContent('#toast')).slice(0, 60));
  // review
  await pg.click('nav [data-s=coffee]');
  await pg.click('.pc[data-id=latte] .pc-rate');
  await pg.click('[data-a=rvOpen]'); await pg.click('[data-a=rvScore][data-n="9"]'); await pg.fill('#rvt', 'Отличный латте'); await pg.click('[data-a=rvSave]');
  await sleep(900);
  await pg.reload(); await pg.waitForSelector('.hd .logo');
  await pg.click('nav [data-s=coffee]'); await pg.click('.pc[data-id=latte] .pc-rate');
  ok(/Отличный латте/.test(await pg.textContent('body')), 'review survived reload (stored in DB)');
  // logout, admin
  await pg.click('nav [data-s=profile]'); await pg.click('[data-a=logout]');
  await pg.waitForSelector('#regform');
  await pg.fill('#nm', 'Админ'); await pg.fill('#ph', '9086929397'); await pg.click('[data-a=sendcode]');
  await pg.waitForSelector('#cd');
  await pg.waitForFunction(() => /Ваш код: \d{6}/.test(document.getElementById('toast').textContent));
  await pg.fill('#cd', (await pg.textContent('#toast')).match(/(\d{6})/)[1]);
  await pg.waitForSelector('#ekey');
  ok(true, 'admin is sent to 2FA enrollment');
  await pg.fill('#ekey', 'wrong'); await pg.click('[data-a=enrollStart]');
  await pg.waitForFunction(() => /не подходит/.test(document.getElementById('regerr').textContent));
  await pg.fill('#ekey', 'setup-key-777'); await pg.click('[data-a=enrollStart]');
  await pg.waitForSelector('#ecode');
  const secret = (await pg.textContent('.mono')).trim();
  await pg.fill('#ecode', totpAt(secret, Math.floor(Date.now() / 30000)));
  await pg.click('[data-a=enrollDone]');
  await pg.waitForSelector('.hd .logo');
  await pg.click('nav [data-s=profile]'); await pg.click('.item[data-s=panel]');
  const tabs = await pg.$$eval('.tabs[data-sk=main] .chip', e => e.map(x => x.textContent));
  console.log('admin tabs', tabs.join(' | '));
  ok(tabs.includes('Безопасность') && tabs.includes('Отчёты') && tabs.includes('Журнал'), 'admin has security tab');
  // people: set Anna manager -> invite
  await pg.click('.tabs[data-sk=main] .chip:has-text("Люди")');
  await pg.click('[data-a=setRole][data-v=manager]');
  await pg.waitForSelector('.mono');
  ok(/^[0-9A-F]{10}$/.test((await pg.textContent('.mono')).trim()), 'invite key shown for new manager');
  // security tab
  await pg.evaluate(() => { document.querySelector('.tabs[data-sk=main]').scrollLeft = 9999; });
  await pg.click('.tabs[data-sk=main] .chip:has-text("Безопасность")');
  await pg.waitForFunction(() => /Сейчас заморожено/.test(document.body.textContent));
  ok(true, 'security tab loads');
  await pg.screenshot({ path: '/tmp/claude-0/-home-claude/e34c477d-6dd5-5818-882c-22ba20439074/scratchpad/ui7-sec.png', fullPage: true });
  // menu edit persists
  await pg.click('.tabs[data-sk=main] .chip:has-text("Меню")');
  await pg.click('[data-a=itemEdit][data-id=latte]');
  await pg.fill('#fp', '245'); await pg.click('[data-a=itemSave]');
  await sleep(1500); console.log('toast:', await pg.textContent('#toast'));
  await pg.reload(); await pg.waitForSelector('#app .hd, #app .page');
  await pg.click('nav [data-s=coffee]');
  console.log('card:', (await pg.textContent('.pc[data-id=latte]')).slice(0,80)); ok(/215/.test(await pg.textContent('.pc[data-id=latte]')), 'price change saved on server and survives reload');
  console.log(errs.length ? errs.join('\n') : 'no console errors');
  await b.close(); srv.kill();
})().catch(e => { console.log('TESTFAIL', e.message); console.log(slog.slice(-800)); srv.kill(); process.exit(1); });
