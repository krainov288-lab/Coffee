const { chromium } = require('playwright');
const fs = require('node:fs'), os = require('node:os'), path = require('node:path'), crypto = require('node:crypto');
const { createApp } = require('../lib/app');
const { totpAt } = require('../lib/secure');
const SS = '/tmp/claude-0/-home-claude/e34c477d-6dd5-5818-882c-22ba20439074/scratchpad/';
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'qcu8-'));
const app = createApp({ dataDir: dir, master: crypto.randomBytes(32), env: { QC_DEV_SMS: '1', QC_ADMIN_PHONE: '9086929397', QC_ADMIN_SETUP_KEY: 'k' } });
const srv = app.createServer();
const ok = (c, m) => console.log((c ? 'PASS ' : 'FAIL ') + m);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let base;
const api = (ck) => async (m, u, b) => { const r = await fetch(base + u, { method: m, headers: { 'content-type': 'application/json', 'x-qc': '1', cookie: ck.v || '', origin: base, 'user-agent': 'T' }, body: b ? JSON.stringify(b) : undefined }); const sc = r.headers.get('set-cookie'); if (sc) ck.v = sc.split(';')[0]; return r.json().catch(() => ({})); };
const login = async (call, phone, name) => { const a = await call('POST', '/api/auth/otp', { phone, name }); return call('POST', '/api/auth/verify', { phone, code: a.devCode, name }); };
async function uiLogin(pg, phone, name) {
  await pg.goto(base + '/'); await pg.waitForSelector('#regform');
  await pg.fill('#nm', name); await pg.fill('#ph', phone); await pg.click('[data-a=sendcode]'); await pg.waitForSelector('#cd');
  await pg.waitForFunction(() => /Ваш код: \d{6}/.test(document.getElementById('toast').textContent));
  await pg.fill('#cd', (await pg.textContent('#toast')).match(/(\d{6})/)[1]);
}
(async () => {
  await new Promise(r => srv.listen(0, '127.0.0.1', r)); base = 'http://127.0.0.1:' + srv.address().port;
  const ck = {}, A = api(ck); await login(A, '9086929397', 'Админ');
  let r = await A('POST', '/api/auth/enroll', { key: 'k' }); const sec = r.secret; await A('POST', '/api/auth/enroll/confirm', { code: totpAt(sec, Math.floor(Date.now() / 30000)) });
  const b = await chromium.launch();
  const mk = async (w, h) => { const c = await b.newContext({ viewport: { width: w, height: h } }); const p = await c.newPage(); p.on('pageerror', e => console.log('PAGEERR', e.message)); await p.route('**/jsQR.js', x => x.fulfill({ contentType: 'text/javascript', body: 'window.jsQR=function(){return null}' })); await p.route('**/qrcode.js', x => x.fulfill({ contentType: 'text/javascript', body: 'window.qrcode=function(){return {addData(){},make(){},getModuleCount(){return 21},isDark(r,c){return (r*c+r)%3==0}}}' })); await p.route(/fonts\.(googleapis|gstatic)\.com/, x => x.abort()); return p; };
  // barista registers via UI first (so admin can promote)
  const ba = await mk(400, 860); await uiLogin(ba, '9001111111', 'Игорь'); await ba.waitForSelector('.hd .logo');
  await ba.click('nav [data-s=profile]'); await ba.click('[data-a=logout]');
  r = await A('POST', '/api/admin/role', { phone: '9001111111', role: 'barista' }); const inv = r.invite;
  const t0 = Date.now();
  r = await A('POST', '/api/shift/plan', { phone: '9001111111', start: t0 + 3 * 6e4, end: t0 + 8 * 36e5 }); ok(r.state && r.state.shifts.length === 1, 'admin planned shift via API');
  // barista logs in via UI -> enroll
  await uiLogin(ba, '9001111111', 'Игорь'); await ba.waitForSelector('#ekey');
  await ba.fill('#ekey', inv); await ba.click('[data-a=enrollStart]'); await ba.waitForSelector('#ecode');
  const bsec = (await ba.textContent('.mono')).trim(); await ba.fill('#ecode', totpAt(bsec, Math.floor(Date.now() / 30000))); await ba.click('[data-a=enrollDone]');
  await ba.waitForSelector('.hd .logo');
  ok(/Приступить/.test(await ba.textContent('.banner')), 'barista sees "Приступить?" banner at shift time');
  await ba.screenshot({ path: SS + 'u8-barista-home.png' });
  await ba.click('nav [data-s=profile]'); await ba.click('.item[data-s=panel]');
  ok(/Моя смена/.test(await ba.textContent('.tabs[data-sk=main]')), 'barista has "Моя смена" tab');
  await ba.screenshot({ path: SS + 'u8-myshift.png', fullPage: true });
  // client orders before shift starts
  const cl = await mk(400, 860); await uiLogin(cl, '9002222222', 'Анна'); await cl.waitForSelector('.hd .logo');
  const place = async (id) => { await cl.click('nav [data-s=coffee]'); await cl.click('.pc[data-id=' + id + ']'); await cl.click('[data-a=addDrink]'); await cl.click('nav [data-s=cart]'); if (!(await cl.locator('[data-a=doPay]').count())) await cl.click('[data-s=pay]'); await cl.click('[data-a=doPay]'); await cl.waitForSelector('.hero'); };
  await place('latte');
  ok(/Ждём бариста/.test(await cl.textContent('.hero')), 'client: waiting for barista before shift starts');
  // barista starts shift
  await ba.click('[data-a=shiftStart]'); await ba.waitForSelector('.qgrid');
  ok(await ba.locator('.qc').count() === 1, 'barista window shows the order');
  ok(/ждёт/.test(await ba.textContent('.qc')) && /Стол/.test(await ba.textContent('.qc')), 'card shows table and waiting time');
  // pre-existing 7 more orders for the grid screenshot
  const ck2 = {}, C = api(ck2); await login(C, '9003333333', 'Борис');
  for (let i = 0; i < 7; i++) await C('POST', '/api/order', { lines: [{ id: ['cappuccino', 'raf', 'croissant', 'espresso', 'mocha', 'ham', 'iced'][i], qty: 1 + (i % 2) }], mode: i % 2 ? 'togo' : 'hall', serve: i % 2 ? 'pickup' : 'table', table: 3 + i, when: 'asap', tip: 0 });
  await ba.waitForFunction(() => document.querySelectorAll('.qc').length === 8, null, { timeout: 8000 });
  ok(true, 'barista window updates by itself: 8 orders');
  await ba.screenshot({ path: SS + 'u8-queue-phone.png' });
  // take first order
  await ba.click('.qc:first-child .qok');
  await ba.waitForSelector('.qc.cook');
  ok(await ba.locator('.qc.cook .qok.on').count() === 1, 'circle turns bright green');
  await cl.waitForFunction(() => /Готовим ваш кофе/.test(document.querySelector('.hero').textContent), null, { timeout: 8000 });
  ok(/\d\d:\d\d/.test(await cl.textContent('.hero .big')), 'client sees "Готовится" and a countdown');
  // late: push due into the past
  const q = app.store.get('queue', (await cl.evaluate(() => document.querySelector('h1.h1').textContent)).replace('Заказ ', '')); q.due = Date.now() - 3 * 6e4; app.store.put('queue', q.id, q); { const uu = app.store.get('users', app.vault.idx('9002222222')); uu.orders.find(o => o.id === q.id).due = q.due; app.store.put('users', app.vault.idx('9002222222'), uu); } app.staffTick();
  await ba.waitForSelector('.qc.late .qok.red', { timeout: 8000 });
  ok(true, 'overdue: circle becomes red');
  await ba.screenshot({ path: SS + 'u8-queue-late.png' });
  await cl.evaluate(() => { }); 
  const late = await cl.waitForFunction(() => /задерживается|вот-вот/.test(document.querySelector('.hero').textContent), null, { timeout: 12000 }).then(() => true).catch(() => false);
  ok(late, 'client sees apology message');
  await cl.screenshot({ path: SS + 'u8-client-late.png' });
  // close: cross -> confirm -> yes
  await ba.click('.qc.late .qx'); await ba.waitForSelector('.qask');
  ok(/готов\?/.test(await ba.textContent('.qask')), 'cross asks "Заказ готов?"');
  await ba.click('.qask [data-a=qNo]'); ok(await ba.locator('.qask').count() === 0, '"Нет" cancels');
  await ba.click('.qc.late .qx'); await ba.click('.qask [data-a=qYes]');
  await ba.waitForFunction(() => document.querySelectorAll('.qc').length === 7);
  ok(true, 'after "Да" the order closes');
  await cl.waitForFunction(() => /Несём на столик/.test(document.querySelector('.hero').textContent), null, { timeout: 8000 });
  ok(true, 'client: "готов, несём на столик"');
  // tablet screenshot
  const tb = await mk(1024, 768); await uiLogin(tb, '9001111111', 'Игорь'); await tb.waitForSelector('#tcode');
  const st = app.store.get('users', app.vault.idx('9001111111')); await tb.fill('#tcode', totpAt(bsec, Math.floor(Date.now() / 30000) + 1));
  await tb.waitForSelector('.hd .logo'); await tb.click('nav [data-s=queue]'); await tb.waitForSelector('.qgrid');
  await tb.screenshot({ path: SS + 'u8-queue-tablet.png' });
  ok(await tb.locator('.qc').count() === 7, 'tablet window works too');
  // admin UI: staff tab
  const ad = await mk(400, 860); await uiLogin(ad, '9086929397', 'Админ'); await ad.waitForSelector('#tcode');
  await ad.fill('#tcode', totpAt(sec, Math.floor(Date.now() / 30000) + 1)); await ad.waitForSelector('nav [data-s=profile]');
  await ad.click('nav [data-s=profile]'); await ad.click('.item[data-s=panel]');
  await ad.evaluate(() => { document.querySelector('.tabs[data-sk=main]').scrollLeft = 9999; });
  await ad.click('.tabs[data-sk=main] .chip:has-text("Персонал")');
  await ad.waitForFunction(() => /Расчёт за период/.test(document.body.textContent) && /Игорь/.test(document.body.textContent));
  ok(/на смене с/.test(await ad.textContent('body')), 'admin sees barista "на работе"');
  await ad.screenshot({ path: SS + 'u8-staff.png', fullPage: true });
  await ad.click('[data-a=stOpen]');
  await ad.waitForFunction(() => /Действия и выполненные заказы/.test(document.body.textContent));
  ok(/приготовил заказ/.test(await ad.textContent('body')), 'barista profile shows per-order log');
  await ad.screenshot({ path: SS + 'u8-staff-detail.png', fullPage: true });
  await ad.click('[data-a=stBack]');
  await ad.click('.tabs[data-sk=main] .chip:has-text("Смены")');
  await ad.waitForSelector('#shp'); await ad.selectOption('#shp', { index: 1 });
  await ad.fill('#shd', new Date(Date.now() + 2 * 864e5).toISOString().slice(0, 10)); await ad.click('[data-a=shPlan]');
  await ad.waitForFunction(() => document.querySelectorAll('[data-a=shDel]').length === 1, null, { timeout: 6000 });
  ok(true, 'admin plans a second shift in UI');
  await ad.click('[data-a=otOpen] >> nth=0'); await ad.click('[data-a=otMin][data-v="240"]'); await ad.click('[data-a=otSave]');
  await sleep(700); console.log('toast:', (await ad.textContent('#toast')).slice(0, 80));
  await ad.screenshot({ path: SS + 'u8-shifts.png', fullPage: true });
  await b.close(); srv.close(); app.close();
})().catch(e => { console.log('TESTFAIL', e.message); process.exit(1); });
